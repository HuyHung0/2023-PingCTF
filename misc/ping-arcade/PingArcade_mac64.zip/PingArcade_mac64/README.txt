1) Make sure it's executable:
	chmod +R 777 PingArcade_mac64.app
2) Ctrl+click and open